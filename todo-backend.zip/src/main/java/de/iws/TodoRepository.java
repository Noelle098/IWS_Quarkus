package de.iws;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class TodoRepository implements PanacheRepository<Todo> {
	public List<Todo> getAll() {
		return listAll();
	}

	public void save(Todo todo) {
		persist(todo);
	}
	
	public void updateName(Long id, String name) {
		Todo todo = findById(id);
		todo.setName(name);
		persist(todo);
	}
	
	public void updateCompleted(Long id) {
		Todo todo = findById(id);
		todo.setCompleted(!todo.isCompleted());
		persist(todo);
	}

	public void loeschen(Todo todo) {
		delete(todo);
	}
}
