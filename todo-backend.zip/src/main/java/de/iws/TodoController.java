package de.iws;

import java.util.List;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

@Path("/todo")
public class TodoController {
	
	@Inject
	TodoRepository todoRepo;

    @GET
    public List<Todo> getAll() {
        return todoRepo.getAll();
    }
    
    @POST
    @Transactional
    @Consumes("application/json")
    public void persist(String name) {
        todoRepo.save(new Todo(name));
    }
    
    @PUT
    @Transactional
    @Consumes("application/json")
    @Path("/name/{id}")
    public void updateName(@PathParam(value = "id") Long id, String name) {
        todoRepo.updateName(id, name);
    }
    
    @PUT
    @Transactional
    @Consumes("application/json")
    @Path("/completed/{id}")
    public void updateCompleted(@PathParam(value = "id") Long id) {
        todoRepo.updateCompleted(id);
    }
    
    @DELETE
    @Transactional
    @Consumes("application/json")
    public void delete(@QueryParam(value = "id") Long id) {
        todoRepo.loeschen(new Todo(id));
    }
}