package org.acme;

public class PetRepository {

}
