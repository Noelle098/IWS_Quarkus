package org.acme;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class PetRepository implements PanacheRepository<Pet> {

    public List<Pet> getAll() {
        return listAll();
    }

    public void savePet(Pet pet) {
        persist(pet);
    }

    public void removePet(Pet pet) {
        delete(pet);
    }

    public Pet getOne(Long id) {
        return findById(id);
    }
}
