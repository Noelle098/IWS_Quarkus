package org.acme;

import java.util.List;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;

@Path("pet")
public class PetController {

    @Inject
    PetRepository petRepo;
    
    @Inject
    CategoryRepository catRepo;

    @GET
    @Path("/list")
    public List<Pet> list() {
        return petRepo.getAll();
    }

    @POST
    @Transactional
    public void addPet(Pet pet) {

        if(pet.getId() != null) {
            throw new WebApplicationException("Id wurde trotz Autowert gesetzt.", 422);
        } else if(catRepo.getOne(pet.getCategory().getId()) == null) {
            return ;
        }

        pet.setCategory(catRepo.getOne(pet.getCategory().getId()));

        petRepo.savePet(pet);
    }

    @PUT
    @Transactional
    public void editPet(Pet pet) {

        if(catRepo.getOne(pet.getCategory().getId()) == null) {
            return ;
        }

        Pet petEntity = petRepo.getOne(pet.getId());

        if(petEntity == null) {
            return ;
        }

        petEntity.setName(pet.getName());
        petEntity.setQuantity(pet.getQuantity());
        petEntity.setCategory(catRepo.getOne(pet.getCategory().getId()));
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public void deletePet(@PathParam("id") Long id) {
        Pet pet = petRepo.getOne(id);

        if(pet == null) {
            return ;
        }

        petRepo.removePet(pet);
    }
}
