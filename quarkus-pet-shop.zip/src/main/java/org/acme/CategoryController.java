package org.acme;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/category")
public class CategoryController {

    @Inject
    CategoryRepository catRepo;

    @GET
    @Path("/list")
    public List<Category> list() {
        return catRepo.getAll();
    }

}
