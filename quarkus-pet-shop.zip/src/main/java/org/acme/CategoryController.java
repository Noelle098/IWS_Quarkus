package org.acme;

public class CategoryController {

}
