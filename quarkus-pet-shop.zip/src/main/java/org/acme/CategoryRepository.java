package org.acme;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

@ApplicationScoped
public class CategoryRepository implements PanacheRepository<Category> {

    public List<Category> getAll() {
        return listAll();
    }

    public Category getOne(Long id) {
        return findById(id);
    }
}
