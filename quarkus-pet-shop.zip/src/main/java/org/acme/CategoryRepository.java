package org.acme;

public class CategoryRepository {

}
