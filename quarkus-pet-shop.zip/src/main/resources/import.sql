-- Categories
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Hund');
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Katze');
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Vogel');
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Repitl');
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Nagetier');
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Pferd');
INSERT INTO CATEGORY (ID, NAME) VALUES (NEXT VALUE FOR category_id_seq, 'Fisch');

-- Insert some animals for tests
INSERT INTO PET (ID, NAME, QUANTITY, CAT_ID) VALUES (NEXT VALUE FOR pet_id_seq, 'Labrador braun', 3, 1);
INSERT INTO PET (ID, NAME, QUANTITY, CAT_ID) VALUES (NEXT VALUE FOR pet_id_seq, 'gelbe Voegel', 2, 3);